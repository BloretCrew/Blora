package net.deechael.blora.dialog.action

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Serializable

@Serializable
data class SuggestCommandClickType(
    val command: String,
    val type: String = "suggest_command"
): ClickType() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("command", NBTString(this@SuggestCommandClickType.command))
            this.setTag("type", NBTString(this@SuggestCommandClickType.type))
        }
    }

}

