package net.deechael.blora.dialog.action

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Serializable

@Serializable
data class OpenFileClickType(
    val path: String,
    val type: String = "open_file"
): ClickType() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("path", NBTString(this@OpenFileClickType.path))
            this.setTag("type", NBTString(this@OpenFileClickType.type))
        }
    }

}
