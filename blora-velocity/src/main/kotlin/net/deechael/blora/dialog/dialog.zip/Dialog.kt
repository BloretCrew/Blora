package net.deechael.blora.dialog

import io.netty.buffer.ByteBuf
import io.netty.buffer.Unpooled
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToByteArray
import kotlinx.serialization.json.ClassDiscriminatorMode
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonNamingStrategy
import kotlinx.serialization.modules.SerializersModule
import net.benwoodworth.knbt.Nbt
import net.benwoodworth.knbt.NbtCompression
import net.benwoodworth.knbt.NbtVariant
import net.deechael.blora.extension.writeVarInt
import net.deechael.blora.serialization.serializer.jsonComponentSupport
import net.deechael.blora.serialization.serializer.keySupport
import net.deechael.blora.serialization.serializer.nbtComponentSupport

@Serializable
sealed class Dialog {

    abstract fun toNBT(): NBTCompound

}

@OptIn(ExperimentalSerializationApi::class)
val DIALOG_JSON = Json {
    encodeDefaults = true
    ignoreUnknownKeys = true
    classDiscriminatorMode = ClassDiscriminatorMode.NONE
    namingStrategy = JsonNamingStrategy.SnakeCase
    decodeEnumsCaseInsensitive = true // useless for now
    explicitNulls = false
    serializersModule = SerializersModule {
        jsonComponentSupport()
        keySupport()
    }
}

fun Dialog.asPacket(): ByteBuf {
    val byteBuf = Unpooled.buffer()
    byteBuf.writeVarInt(0x85)
    byteBuf.writeBytes(
        Nbt {
            variant = NbtVariant.Java
            compression = NbtCompression.Gzip
            serializersModule = SerializersModule {
                nbtComponentSupport()
                keySupport()
            }
        }.encodeToByteArray(this)
    )
    return byteBuf
}

fun Dialog.encodeToString(): String {
    return DIALOG_JSON.encodeToString(this)
}