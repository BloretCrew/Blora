package net.deechael.blora.dialog.action

import com.github.retrooper.packetevents.protocol.nbt.NBT
import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTInt
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Serializable

@Serializable
data class ChangePageCommandClickType(
    val page: Int,
    val type: String = "change_page"
): ClickType() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("page", NBTInt(this@ChangePageCommandClickType.page))
            this.setTag("type", NBTString(this@ChangePageCommandClickType.type))
        }
    }

}
