package net.deechael.blora.dialog.action

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Serializable
import net.deechael.blora.converter.toPacketEvents

@Serializable
data class DynamicRunCommandClickType(
    val template: String,
    val type: String = "dynamic/run_command"
): ClickType() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("template", NBTString(this@DynamicRunCommandClickType.template))
            this.setTag("type", NBTString(this@DynamicRunCommandClickType.type))
        }
    }

}

