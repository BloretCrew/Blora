package net.deechael.blora.dialog.action

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Serializable

@Serializable
data class RunCommandClickType(
    val command: String,
    val type: String = "run_command"
): ClickType() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("command", NBTString(this@RunCommandClickType.command))
            this.setTag("type", NBTString(this@RunCommandClickType.type))
        }
    }

}
