package net.deechael.blora.dialog.action

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTInt
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Serializable

@Serializable
data class CopyToClipboardClickType(
    val value: String,
    val type: String = "copy_to_clipboard"
): ClickType() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("value", NBTString(this@CopyToClipboardClickType.value))
            this.setTag("type", NBTString(this@CopyToClipboardClickType.type))
        }
    }

}
