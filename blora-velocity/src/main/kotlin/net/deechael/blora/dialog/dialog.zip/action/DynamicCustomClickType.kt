package net.deechael.blora.dialog.action

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Serializable
import net.benwoodworth.knbt.NbtTag
import net.deechael.blora.converter.toPacketEvents

@Serializable
data class DynamicCustomClickType(
    val id: String,
    val additions: NbtTag? = null,
    val type: String = "dynamic/custom"
): ClickType() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("id", NBTString(this@DynamicCustomClickType.id))
            if (this@DynamicCustomClickType.additions != null) {
                this.setTag("additions", this@DynamicCustomClickType.additions.toPacketEvents()!!)
            }
            this.setTag("type", NBTString(this@DynamicCustomClickType.type))
        }
    }

}


