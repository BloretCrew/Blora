package net.deechael.blora.dialog.action

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Serializable

@Serializable
data class OpenUrlClickType(
    val url: String,
    val type: String = "open_url"
): ClickType() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("url", NBTString(this@OpenUrlClickType.url))
            this.setTag("type", NBTString(this@OpenUrlClickType.type))
        }
    }

}
