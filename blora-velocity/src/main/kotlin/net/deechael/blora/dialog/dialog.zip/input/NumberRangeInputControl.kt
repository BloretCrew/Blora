@file:OptIn(ExperimentalSerializationApi::class)

package net.deechael.blora.dialog.input

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Contextual
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import net.deechael.blora.converter.toNBT
import net.kyori.adventure.text.Component

@Serializable
data class NumberRangeInputControl(
    val key: String,
    @Contextual
    val label: Component,
    val start: Float, // inclusive
    val end: Float, // inclusive
    val step: Float? = null,
    val labelFormat: String = "options.generic_value",
    val width: Int = 200,
    val initial: Float? = null, // will be rounded down nearest step, must be within range
    val type: String = "minecraft:number_range"
) : InputControl() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("key", this@NumberRangeInputControl.key.toNBT())
            this.setTag("label", label.toNBT())
            this.setTag("start", start.toNBT())
            this.setTag("end", end.toNBT())
            if (this@NumberRangeInputControl.step != null) {
                this.setTag("step", step.toNBT())
            }
            this.setTag("labelFormat", labelFormat.toNBT())
            this.setTag("width", width.toNBT())
            if (this@NumberRangeInputControl.initial != null) {
                this.setTag("initial", initial.toNBT())
            }
            this.setTag("type", NBTString(this@NumberRangeInputControl.type))
        }
    }

}

