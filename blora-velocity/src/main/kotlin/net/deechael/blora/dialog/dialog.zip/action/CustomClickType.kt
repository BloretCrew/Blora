package net.deechael.blora.dialog.action

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Serializable

@Serializable
data class CustomClickType(
    val id: String,
    val payload: String? = null,
    val type: String = "custom"
): ClickType() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("id", NBTString(this@CustomClickType.id))
            if (this@CustomClickType.payload != null) {
                this.setTag("payload", NBTString(this@CustomClickType.payload))
            }
            this.setTag("type", NBTString(this@CustomClickType.type))
        }
    }

}

