package net.deechael.blora.dialog.body

import com.github.retrooper.packetevents.protocol.nbt.NBTByte
import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTInt
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Contextual
import kotlinx.serialization.Serializable
import net.deechael.blora.converter.toNBT
import net.kyori.adventure.text.Component

@Serializable
data class PlainMessageDialogBody(
    @Contextual
    val contents: Component,
    val width: Int = 200,
    val type: String = "minecraft:plain_message"
) : DialogBody() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("contents", this@PlainMessageDialogBody.contents.toNBT())
            this.setTag("width", NBTInt(width))
            this.setTag("type", NBTString(this@PlainMessageDialogBody.type))
        }
    }

}

