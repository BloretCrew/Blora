package net.deechael.blora.dialog.action

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Serializable
import net.deechael.blora.dialog.Dialog

@Serializable
data class ShowDialogClickType(
    val dialog: String, // id or inline
    val type: String = "show_dialog"
): ClickType() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("dialog", NBTString(this@ShowDialogClickType.dialog))
            this.setTag("type", NBTString(this@ShowDialogClickType.type))
        }
    }

}

@Serializable
data class ShowInlineDialogClickType(
    val dialog: Dialog,
    val type: String = "show_dialog"
): ClickType() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("dialog", this@ShowInlineDialogClickType.dialog.toNBT())
            this.setTag("type", NBTString(this@ShowInlineDialogClickType.type))
        }
    }

}
