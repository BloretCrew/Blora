@file:OptIn(ExperimentalSerializationApi::class)

package net.deechael.blora.dialog.body

import com.github.retrooper.packetevents.protocol.nbt.NBTByte
import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTInt
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Contextual
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName
import net.deechael.blora.converter.toNBT
import net.deechael.blora.item.ItemStack
import net.kyori.adventure.text.Component

@Serializable
data class ItemDescription(
    @Contextual
    val contents: Component,
    val width: Int = 200
) {

    fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("contents", this@ItemDescription.contents.toNBT())
            this.setTag("width", NBTInt(this@ItemDescription.width))
        }
    }

}



@Serializable
data class ItemDialogBody(
    val item: ItemStack,
    val description: ItemDescription? = null,
    @SerialName("show_decorations")
    val showDecorations: Boolean = true,
    @SerialName("show_tooltip")
    val showTooltip: Boolean = true,
    val width: Int = 16,
    val height: Int = 16,
    val type: String = "minecraft:item"

) : DialogBody() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("item", this@ItemDialogBody.item.toNBT())
            if (this@ItemDialogBody.description != null) {
                this.setTag("description", this@ItemDialogBody.description.toNBT())
            }
            this.setTag("show_decoration", NBTByte(if (this@ItemDialogBody.showDecorations) 1 else 0))
            this.setTag("show_tooltip", NBTByte(if (this@ItemDialogBody.showTooltip) 1 else 0))
            this.setTag("width", NBTInt(width))
            this.setTag("height", NBTInt(height))
            this.setTag("type", NBTString(this@ItemDialogBody.type))
        }
    }

}

