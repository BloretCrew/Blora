package net.deechael.blora.dialog.input

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import kotlinx.serialization.Serializable

@Serializable
sealed class InputControl {

    abstract fun toNBT(): NBTCompound

}