@file:OptIn(ExperimentalSerializationApi::class)

package net.deechael.blora.dialog.input

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTInt
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.Contextual
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName
import net.deechael.blora.converter.toNBT
import net.kyori.adventure.text.Component

@Serializable
data class BooleanInputControl(
    val key: String,
    @Contextual
    val label: Component,
    val initial: Boolean = false,
    @SerialName("on_true")
    val onTrue: String = "true",
    @SerialName("on_false")
    val onFalse: String = "false",
    val type: String = "minecraft:boolean"
) : InputControl() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("key", this@BooleanInputControl.key.toNBT())
            this.setTag("label", label.toNBT())
            this.setTag("initial", initial.toNBT())
            this.setTag("on_true", onTrue.toNBT())
            this.setTag("on_false", onFalse.toNBT())
            this.setTag("type", NBTString(this@BooleanInputControl.type))
        }
    }

}

