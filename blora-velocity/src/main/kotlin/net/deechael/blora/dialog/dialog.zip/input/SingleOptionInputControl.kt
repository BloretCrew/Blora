@file:OptIn(ExperimentalSerializationApi::class)

package net.deechael.blora.dialog.input

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTList
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import com.github.retrooper.packetevents.protocol.nbt.NBTType
import kotlinx.serialization.Contextual
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName
import net.deechael.blora.converter.toNBT
import net.kyori.adventure.text.Component

@Serializable
data class InputControlOption(
    val id: String,
    @Contextual
    val display: Component? = null,
    val initial: Boolean = false
) {

    fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("id", id.toNBT())
            if (display != null) {
                this.setTag("display", display.toNBT())
            }
            this.setTag("initial", initial.toNBT())
        }
    }

}

@Serializable
data class SingleOptionInputControl(
    val key: String,
    @Contextual
    val label: Component,
    val options: List<InputControlOption>,
    @SerialName("label_visible")
    val labelVisible: Boolean = true,
    val width: Int = 200,
    val type: String = "minecraft:single_option"
) : InputControl() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("key", this@SingleOptionInputControl.key.toNBT())
            this.setTag("label", label.toNBT())
            this.setTag("options", NBTList(NBTType.COMPOUND).apply {
                for (option in options) {
                    this.addTag(option.toNBT())
                }
            })
            this.setTag("label_visible", labelVisible.toNBT())
            this.setTag("width", width.toNBT())
            this.setTag("type", NBTString(this@SingleOptionInputControl.type))
        }
    }

}