package net.deechael.blora.dialog.body

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import kotlinx.serialization.Serializable

@Serializable
sealed class DialogBody {

    abstract fun toNBT(): NBTCompound

}