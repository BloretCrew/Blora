package net.deechael.blora.dialog.action

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import kotlinx.serialization.Serializable

@Serializable
sealed class ClickType {

    abstract fun toNBT(): NBTCompound

}