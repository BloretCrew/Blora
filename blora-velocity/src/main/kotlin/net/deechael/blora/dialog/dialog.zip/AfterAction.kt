package net.deechael.blora.dialog

import com.github.retrooper.packetevents.protocol.nbt.NBTString
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
enum class AfterAction {

    @SerialName("close")
    CLOSE,
    @SerialName("none")
    NONE,
    @SerialName("wait_for_response")
    WAIT_FOR_RESPONSE;

    fun toNBT(): NBTString {
        return NBTString(this.name.lowercase())
    }

}