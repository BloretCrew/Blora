@file:OptIn(ExperimentalSerializationApi::class)

package net.deechael.blora.dialog

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTList
import com.github.retrooper.packetevents.protocol.nbt.NBTType
import kotlinx.serialization.Contextual
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName
import net.deechael.blora.converter.toNBT
import net.deechael.blora.dialog.action.ClickAction
import net.deechael.blora.dialog.body.DialogBody
import net.deechael.blora.dialog.input.InputControl
import net.kyori.adventure.text.Component

@Serializable
data class NoticeDialog(
    @Contextual
    val title: Component,
    @SerialName("external_title")
    @Contextual
    val externalTitle: Component? = null,
    val body: List<DialogBody>? = null,
    val inputs: List<InputControl>? = null,
    @SerialName("can_close_with_escape")
    val canCloseWithEscape: Boolean = true,
    val pause: Boolean = true,
    @SerialName("after_action")
    val afterAction: AfterAction = AfterAction.CLOSE,
    val action: ClickAction = ClickAction(
        label = Component.translatable("gui.ok")
    ),
    val type: String = "minecraft:notice"
) : Dialog() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("title", title.toNBT())
            this.setTag("external_title", externalTitle?.toNBT())
            if (body != null) {
                this.setTag("body", NBTList(NBTType.COMPOUND).apply {
                    for (b in body) {
                        this.addTag(b.toNBT())
                    }
                })
            }
            if (inputs != null) {
                this.setTag("inputs", NBTList(NBTType.COMPOUND).apply {
                    for (input in inputs) {
                        this.addTag(input.toNBT())
                    }
                })
            }
            this.setTag("can_close_with_escape", canCloseWithEscape.toNBT())
            this.setTag("pause", pause.toNBT())
            this.setTag("after_action", afterAction.toNBT())
            this.setTag("type", this@NoticeDialog.type.toNBT())

            this.setTag("action", action.toNBT())
        }
    }

}
