@file:OptIn(ExperimentalSerializationApi::class)

package net.deechael.blora.dialog.input

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import com.github.retrooper.packetevents.protocol.nbt.NBTList
import com.github.retrooper.packetevents.protocol.nbt.NBTString
import com.github.retrooper.packetevents.protocol.nbt.NBTType
import kotlinx.serialization.Contextual
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName
import net.deechael.blora.converter.toNBT
import net.kyori.adventure.text.Component

@Serializable
data class Multiline(
    @SerialName("max_lines")
    val maxLines: Int? = null,
    val height: Int? = null
) {

    fun toNBT(): NBTCompound? {
        if (this.maxLines == null && this.height == null) {
            return null
        }
        return NBTCompound().apply {
            if (maxLines != null) {
                this.setTag("max_lines", maxLines.toNBT())
            }
            if (height != null) {
                this.setTag("height", height.toNBT())
            }
        }
    }

}

@Serializable
data class TextInputControl(
    val key: String,
    @Contextual
    val label: Component,
    val width: Int = 200,
    @SerialName("label_visible")
    val labelVisible: Boolean = true,
    val initial: String = "",
    @SerialName("max_length")
    val maxLength: Int = 32,
    val multiline: Multiline? = null,
    val type: String = "minecraft:text"
) : InputControl() {

    override fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("key", this@TextInputControl.key.toNBT())
            this.setTag("label", label.toNBT())
            this.setTag("width", width.toNBT())
            this.setTag("label_visible", labelVisible.toNBT())
            this.setTag("initial", initial.toNBT())
            this.setTag("max_length", maxLength.toNBT())
            val multiline = multiline?.toNBT()
            if (multiline != null) {
                this.setTag("multiline", multiline)
            }
            this.setTag("type", NBTString(this@TextInputControl.type))
        }
    }

}