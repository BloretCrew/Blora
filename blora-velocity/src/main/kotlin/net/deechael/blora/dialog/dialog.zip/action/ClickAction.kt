@file:OptIn(ExperimentalSerializationApi::class)

package net.deechael.blora.dialog.action

import com.github.retrooper.packetevents.protocol.nbt.NBTCompound
import kotlinx.serialization.Contextual
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import net.deechael.blora.converter.toNBT
import net.kyori.adventure.text.Component

@Serializable
data class ClickAction(
    @Contextual
    val label: Component,
    @Contextual
    val tooltip: Component? = null,
    val width: Int = 150, // [1, 1024]
    val action: ClickType? = null
) {

    fun toNBT(): NBTCompound {
        return NBTCompound().apply {
            this.setTag("label", label.toNBT())
            this.setTag("tooltip", tooltip?.toNBT())
            this.setTag("width", width.toNBT())
            this.setTag("action", action?.toNBT())
        }
    }

}